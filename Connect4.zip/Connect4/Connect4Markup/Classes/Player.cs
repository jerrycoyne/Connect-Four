﻿/*Jerald Coyne-Ayanna Woodlin
 * Last Updated: 11/12/2018
 * CIS 3309
 * This class is the model class
 * that holds the players
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connect4Markup.Classes
{
    public class Player
    {
        //class variables
        private string name;
        private int playerID; //ID 1 = red ID 2 = blue
        private int hiddenPlayerPieces = 21;

        //parameterless constructor
        public Player()
        {

        }
        
        //end constructor Player
        public Player(string name, int thePlayerID) 
        {
            this.name = name;
            this.playerID = thePlayerID;
        }   

        //setters and getters
        public string getName()
        {
            return name;
        }   

        public int getPlayerID()
        {
            return playerID;
        }
      
        public int getHiddenPieces()
        {
            return hiddenPlayerPieces;
        }
    }   
}   