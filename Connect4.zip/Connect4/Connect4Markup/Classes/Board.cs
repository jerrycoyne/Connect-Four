﻿/*Jerald Coyne-Ayanna Woodlin
 * Last Updated: 11/12/2018
 * CIS 3309
 * This class is the controller
 * class that holds the methods 
 * to record moves and determine winner 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Connect4Markup.Classes
{
    public class Board
    {
        //class variables
        private int[,] board;
        private int hiddenRows = 6;
        private int hiddenCols = 7;
        private int[,] boardMoveRecord = new int[6,7];

        //Constructor
        public Board()
        {
            board = new int[hiddenRows, hiddenCols];
            for(int r = 0; r < hiddenRows; r++) //fills the board with -1 to indicate that the space is empty
            {
                for (int c = 0; c < hiddenCols; c++)
                {
                    board[r, c] = -1;
                }
            }
        }

        //setters and getters
        public int getRows()
        {
            return hiddenRows;
        }

        public int getCols()
        {
            return hiddenCols;
        }

        //method that fills specified location in the array with players ID number. 
        public void recordMove(int row, int col, int playerID)
        {
            boardMoveRecord[row, col] = playerID;
        }

        //determines winner using nested for loops that increment through the 2D array
        //and check for matches of player ID input. 
        public bool isAWinner()
        {
            //checks horizontal win
            for (int i = 0; i < hiddenRows; i++)
            {
                for (int j = 0; j < hiddenCols - 3; j++)
                {
                    if (boardMoveRecord[i,j] != 0 && 
                        boardMoveRecord[i,j] == boardMoveRecord[i,j + 1] && 
                        boardMoveRecord[i,j] == boardMoveRecord[i,j + 2] && 
                        boardMoveRecord[i,j] == boardMoveRecord[i,j + 3])
                        return true;
                }
            }

            //checks vertical win
            for (int i = 0; i < hiddenRows - 3; i++)
            {
                for (int j = 0; j < hiddenCols; j++)
                {
                    if (boardMoveRecord[i,j] != 0 && 
                        boardMoveRecord[i,j] == boardMoveRecord[i + 1,j] && 
                        boardMoveRecord[i,j] == boardMoveRecord[i + 2,j] && 
                        boardMoveRecord[i,j] == boardMoveRecord[i + 3,j])
                        return true;
                }
            }

            //checks rigth diagonal win 
            for (int i = 0; i < hiddenRows - 3; i++)
            {
                for (int j = 0; j < hiddenCols - 3; j++)
                {
                    if (boardMoveRecord[i, j] != 0 && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 1, j + 1] && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 2, j + 2] && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 3, j + 3])
                        return true;
                }
            }
            
            //checks left diagonal win 
            for (int i = 0; i < hiddenRows - 3; i++)
            {
                for (int j = 3; j < hiddenCols; j++)
                {
                    if (boardMoveRecord[i, j] != 0 && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 1, j - 1] && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 2, j - 2] && 
                        boardMoveRecord[i, j] == boardMoveRecord[i + 3, j - 3])
                    return true;
                }
            }
            return false;
        }
    }
}
